# notifications are a dict of dicts
notifications = dict()

###############################################################
# Example notification for project/version, follow this format
###############################################################
# notifications["project_name"] = dict()
# notifications["project_name"]["version_number"] = "Notification message."
