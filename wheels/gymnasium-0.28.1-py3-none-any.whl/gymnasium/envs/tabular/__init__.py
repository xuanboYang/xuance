"""Provides Tabular JAX FuncEnv implementations."""

from gymnasium.envs.tabular.blackjack import BlackJackJaxEnv
