raise ImportError(
    "MAgent has been moved into its own package: MAgent2. Install with `pip install magent2`. For more information on the MAgent2 package, see https://magent2.farama.org/."
)
