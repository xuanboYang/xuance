"""
This module defines string constants for BOS
"""

# Version status
ENABLED = "enabled"
SUSPENDED =  "suspended"
DISABLED = "disabled"
