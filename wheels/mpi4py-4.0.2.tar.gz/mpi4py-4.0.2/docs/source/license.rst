:tocdepth: 1

.. _license:

LICENSE
-------

.. include:: ../../LICENSE.rst
