mpi4py.bench
============

.. module:: mpi4py.bench
   :synopsis: Run MPI benchmarks and tests.

.. versionadded:: 3.0.0
