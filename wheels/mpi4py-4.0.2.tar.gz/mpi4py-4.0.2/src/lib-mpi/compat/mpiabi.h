#ifndef PyMPI_COMPAT_MPIABI_H
#define PyMPI_COMPAT_MPIABI_H

/* -------------------------------------------------------------------------- */

#endif /* !PyMPI_COMPAT_MPIABI_H */
