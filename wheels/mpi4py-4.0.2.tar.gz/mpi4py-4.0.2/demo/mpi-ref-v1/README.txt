@Book{MPI-Ref-V1,
  title =        {{MPI} - The Complete Reference: Volume 1, The {MPI} Core},
  author =       {Marc Snir and Steve Otto and Steven Huss-Lederman
                  and David Walker and Jack Dongarra},
  edition =      {2nd.},
  year =         1998,
  publisher =    {MIT Press},
  volume =       {1, The MPI Core},
  series =       {Scientific and Engineering Computation},
  address =      {Cambridge, MA, USA},
}
