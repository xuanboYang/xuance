__all__ = ("autolog",)

from .openai import AutologOpenAI

autolog = AutologOpenAI()
