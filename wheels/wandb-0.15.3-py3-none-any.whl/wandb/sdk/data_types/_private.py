import tempfile

MEDIA_TMP = tempfile.TemporaryDirectory("wandb-media")
