from .agent import LaunchAgent

LaunchAgent = LaunchAgent

__all__ = ["LaunchAgent"]
