from wandb.cli import cli

cli.cli(prog_name="python -m wandb")
