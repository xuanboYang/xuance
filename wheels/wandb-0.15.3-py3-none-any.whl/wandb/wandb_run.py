"""Compatibility wandb_run module.

In the future use:
    from wandb.sdk.wandb_run import Run
"""

from wandb.sdk.wandb_run import Run

__all__ = ["Run"]
